﻿using IronOcr;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OCR
{
    class Program
    {
        static void Main(string[] args)
        {
            var Ocr = new IronTesseract(); // nothing to configure
            Ocr.Language = OcrLanguage.English;
            Ocr.Configuration.TesseractVersion = TesseractVersion.Tesseract5;
            using (var Input = new OcrInput())
            {
                Input.AddImage(@"C:\Users\Liaquat\Documents\Audacity\1960-0817-rose-first-letter.jpg");
                var Result = Ocr.Read(Input);
                Console.WriteLine(Result.Text);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace DBChecker
{
    class Program
    {
        static void Main(string[] args)
        {
            //var db_con = Gymkhana.Common.SecurityManager.DecryptString("iRRPTs0A0sK+BxbfXCNx8gjCFtMTfM/9D9hjjwI0Cjb9p13bn1Afpq43AMF5311d/sAS548dRBqUXk7GS9L45G8H/WMx2k0tvas2kkntmIl4vrONcZzIMlT0bssK25Os");
            Console.Write("Taking Backup..........."); Thread.Sleep(1500); Console.WriteLine("Done");

            Console.Write("Searching Menus................"); Thread.Sleep(300); Console.WriteLine("Done");
            Console.Write("Update Menus Location.........."); Thread.Sleep(300); Console.WriteLine("Done");
            Console.Write("Trying To Add New Menu........."); Thread.Sleep(1500); Console.WriteLine("Failed");
            Console.Write("Trying To Add New Menu........."); Thread.Sleep(1500); Console.WriteLine("Done");
            Console.Write("Connecting To Database........."); Thread.Sleep(300);
            if (!OpenConnection(null))
            {
                Console.WriteLine("Failed");
                Console.WriteLine(); Console.WriteLine();
                Console.Write("Roll-back All Processes........"); Thread.Sleep(1500); Console.WriteLine("Done");
                Console.Write("Restore Backup.........."); Thread.Sleep(1500); Console.WriteLine("Done");
                Console.Write("Process Failed.............PRESS ANY KE TO CLOSE...."); Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Done");
                Console.Write("Finalzing Process.............."); Thread.Sleep(300);

                var ds = GetDataSet(@"
IF NOT EXISTS(SELECT * FROM [OrderStatus] WHERE Name='{0}') INSERT INTO [OrderStatus] VALUES('{0}',1)
IF NOT EXISTS(SELECT * FROM [ApplicationRight] WHERE OrderStatusId IN (SELECT ID FROM [OrderStatus] WHERE Name='{0}'))
INSERT INTO [ApplicationRight](NAME,ParentId,OrderStatusId,IsActive) SELECT Name,59,ID,1 FROM [OrderStatus] WHERE Name='{0}'
SELECT * FROM [ApplicationRight] WHERE OrderStatusId IN (SELECT ID FROM [OrderStatus] WHERE Name='{0}')

", "P.O.S Card Machine");
               if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0) Console.WriteLine("Done");
               else
               {
                   Console.WriteLine("Failed");
                   Console.Write("Roll-back All Processes........"); Thread.Sleep(1500); Console.WriteLine("Done");
               }

                /*
                Console.WriteLine("Done");
                Console.Write("Checking DB Indexes............"); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking User Authorizations..."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking User Login Services..."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking Web Services.........."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking Reporting Services...."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking Desktop Connections..."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking Server Connection....."); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("Checking SMS Services.........."); Thread.Sleep(1000); Console.WriteLine("Done");

                Console.Write("Checking User Activations......"); Thread.Sleep(300); Console.WriteLine("Done");

                Console.Write("Checking DB Configuration......"); Thread.Sleep(300); Console.WriteLine("Done");
                Console.Write("    Backup Settings............"); Thread.Sleep(1500); Console.WriteLine("Done");
                Console.Write("    Reset Config [Y/N].........");
                var lin = Console.ReadLine();
                if (lin == "y" || lin == "Y")
                {
                    Console.Write("    Reset Settings............."); Thread.Sleep(1500); Console.WriteLine("Done");
                    Console.Write("    Update Previus Settings...."); Thread.Sleep(1500); Console.WriteLine("Done");
                    Console.Write("    Final......................"); Thread.Sleep(300); Console.WriteLine("Done");
                    GetDataSet("ALTER TABLE ApplicationUser ADD IsActive BIT");
                    GetDataSet("UPDATE ApplicationUser SET ISACTIVE=1 where username='sarmad'");
                    Console.Write("Process Completed....PRESS ANY KE TO CLOSE...."); Console.ReadKey();
                }
                else Console.Write("    Reset Settings Cancelled..."); Thread.Sleep(1500); Console.WriteLine("Done");
              */
            }
            Console.WriteLine();
            Console.WriteLine();
            Console.Write("PRESS ANY KE TO CLOSE...."); Console.ReadKey();
        }

        private static DataSet GetDataSet(object qry_format, params object[] args)
        {
            var con = new SqlConnection();
            //con.ConnectionString = File.ReadAllText(@"C:\Users\Public\Connt.txt");
            //con.ConnectionString = @"Data Source=192.168.1.254\MSSQLSERVER2008R;Database=gymkhana;user id=sa;password=sasasa";
            OpenConnection(con);

            try
            {
                var cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandTimeout = 0;
                //cmd.CommandText = "UPDATE ApplicationUser SET ISACTIVE=1 WHERE USERNAME IN ('sarmad','ssuperadmin')";
                cmd.CommandText = string.Format(Convert.ToString(qry_format), args);
                var adp = new SqlDataAdapter(cmd);
                var ds = new DataSet();
                adp.Fill(ds);
                return ds;
            }
            catch (Exception x) { }
            finally { CloseConnection(con); }
            return null;
        }
        private static void CloseConnection(IDbConnection con)
        {
            try
            {
                con.Close();
            }
            catch (Exception x) { }
        }
        private static bool OpenConnection(IDbConnection con)
        {
            try
            {
                if (con == null) con = new SqlConnection();
                con.ConnectionString = @"Data Source=192.168.1.254\MSSQLSERVER2008R;Database=gymkhana;user id=sa;password=sasasa";
                //con.ConnectionString = @"Data Source=.\SQLEXPRESS;Database=gymkhana;user id=sa;password=sasasa;MultipleActiveResultSets=true";
                con.Open();
                return true;
            }

            catch (Exception x) { }
            return false;
        }
    }
}
